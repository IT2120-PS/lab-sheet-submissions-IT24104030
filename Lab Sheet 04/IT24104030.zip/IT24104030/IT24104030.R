setwd("C:\\Users\\it24104030\\Desktop\\IT24104030")
data <- read.table("DATA 4.txt", header=TRUE, sep=" ")
fix(data)
attach(data)

##Part2
##Part(a)
boxplot(X1, main="Box plot for Team Attendance", outline=TRUE, outpch=8, horizontal=TRUE)
boxplot(X2, main="Box plot for Team Salary", outline=TRUE, outpch=8, horizontal=TRUE)
boxplot(X3, main="Box plot for Years", outline=TRUE, outpch=8, horizontal=TRUE)

hist(X1, ylab="Frequency", xlab="Team Attendance", main="Histogram for Team Attendance")
hist(X2, ylab="Frequency", xlab="Team Salary", main="Histogram for Team Salary")
hist(X3, ylab="Frequency", xlab="Years", main="Histogram for Years")

stem(X1)
stem(X2)
stem(X3)

##Part (b)
mean(X1)
mean(X2)
mean(X3)

median(X1)
median(X2)
median(X3)

sd(X1)
sd(X2)
sd(X3)

##Part(c)
summary(X1)
summary(X2)
summary(X3)

quantile(X1)

quantile(X1)[2]

quantile(X1)[4]

##Part(d)
IQR(X1)
IQR(X2)
IQR(X3)

##Part 3
get.mode <- function(v){
  counts <- table(v)
  mode_val <- names(counts[counts == max(counts)])
  return(list("table" = counts, "mode" = mode_val))
}
result <- get.mode(X3)
result$table
result$mode 

max(result$table)
result$table[result$table == max(result$table)] 

##Part 4
get.outliers<-function(z){
  q1 <- quantile(z)[2]
  q3 <- quantile(z)[4]
  iqr <- q3 - q1
  
  ub <- q3 + 1.5*iqr
  lb <- q1 - 1.5*iqr
  
  print(paste("Upper Bound = ", ub))
  print(paste("Lower Bound = ", lb))
  print(paste("Outliers: ", paste(sort(z[z>ub | z<lb]), collapse = ",")))
}

get.outliers(X1)
get.outliers(X2)
get.outliers(X3)

get.outliers<-function(z){
  q1 <- quantile(z)[2]
  q3 <- quantile(z)[4]
  iqr <- q3 - q1
  
  ub <- q3 + 1.5*iqr
  lb <- q1 - 1.5*iqr
  
  print(paste("Upper Bound = ", ub))
  print(paste("Lower Bound = ", lb))
  
  print(paste("Outliers: ", paste(sort(z[z>ub | z<lb]), collapse = ",")))
}

##Exercise
##Part 1
branch_data <- read.csv("Exercise.txt", header=TRUE)
branch_data

##Part 3
boxplot(branch_data$Sales_X1, main="Boxplot for Sales", ylab="Sales")

##Part 4
fivenum(branch_data$Advertising_X2)
IQR(branch_data$Advertising_X2)

##Part  5
get.outliers <- function(z){
  q1 <- quantile(z, 0.25)
  q3 <- quantile(z, 0.75)
  iqr <- q3 - q1
  
  ub <- q3 + 1.5 * iqr
  lb <- q1 - 1.5 * iqr
  
  outliers <- z[z < lb | z > ub]
  return(list("Q1"=q1, "Q3"=q3, "IQR"=iqr, "Lower Bound"=lb, "Upper Bound"=ub, "Outliers"=outliers))
}


